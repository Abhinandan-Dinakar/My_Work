#include "thread.h"

Thread::Thread(QObject *parent) : QThread(parent)
{

}

void Thread::run(){
    while (m_bStart) {
        emit send();
        msleep(40);
    }
}

bool Thread::bStart() const
{
    return m_bStart;
}

void Thread::setStart(bool bStart)
{
    m_bStart = bStart;
}
